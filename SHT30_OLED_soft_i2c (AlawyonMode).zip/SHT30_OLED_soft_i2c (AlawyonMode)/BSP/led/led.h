#ifndef __LED_H
#define __LED_H

#include "stm32f0xx.h"

#define DELAYTIME								2000

//x: 0 --- Bit_RESET,1 --- Bit_SET
//Geeen LED
#define LED1_GPIO_RCC           RCC_AHBPeriph_GPIOB
#define LED1_GPIO_PORT          GPIOB
#define LED1_GPIO_PIN      			GPIO_Pin_3

//Yellow LED
#define LED2_GPIO_RCC           RCC_AHBPeriph_GPIOB
#define LED2_GPIO_PORT          GPIOB
#define LED2_GPIO_PIN      			GPIO_Pin_4

//Red LED
#define LED3_GPIO_RCC           RCC_AHBPeriph_GPIOB
#define LED3_GPIO_PORT          GPIOB
#define LED3_GPIO_PIN      			GPIO_Pin_5

#define LED_G_ON								GPIO_WriteBit(GPIOB,GPIO_Pin_3,Bit_RESET);\
																GPIO_WriteBit(GPIOB,GPIO_Pin_4,Bit_SET);\
																GPIO_WriteBit(GPIOB,GPIO_Pin_5,Bit_SET)
																
#define LED_Y_ON								GPIO_WriteBit(GPIOB,GPIO_Pin_3,Bit_SET);\
																GPIO_WriteBit(GPIOB,GPIO_Pin_4,Bit_RESET);\
																GPIO_WriteBit(GPIOB,GPIO_Pin_5,Bit_SET)
																
#define LED_R_ON								GPIO_WriteBit(GPIOB,GPIO_Pin_3,Bit_SET);\
																GPIO_WriteBit(GPIOB,GPIO_Pin_4,Bit_SET);\
																GPIO_WriteBit(GPIOB,GPIO_Pin_5,Bit_RESET)

void LED_GPIO_Config(void);	

#endif
