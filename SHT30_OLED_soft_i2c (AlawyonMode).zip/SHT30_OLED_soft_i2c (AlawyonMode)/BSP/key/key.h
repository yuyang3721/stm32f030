#ifndef __KEY_H
#define	__KEY_H

#include "stm32f0xx.h"
//KEY1(PA8)
#define KEY1_BUTTON_PIN                   GPIO_Pin_8
#define KEY1_BUTTON_GPIO_PORT             GPIOA
#define KEY1_BUTTON_GPIO_RCC              RCC_AHBPeriph_GPIOA
#define KEY1_Status_Read()								GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)

#define KEY1_BUTTON_EXTI_PORT_SOURCE      EXTI_PortSourceGPIOA
#define KEY1_BUTTON_EXTI_PIN_SOURCE       EXTI_PinSource8
#define KEY1_BUTTON_EXTI_LINE             EXTI_Line8
#define KEY1_BUTTON_EXTI_IRQn             EXTI4_15_IRQn

//KEY2(PA11)
#define KEY2_BUTTON_PIN                   GPIO_Pin_11
#define KEY2_BUTTON_GPIO_PORT             GPIOA
#define KEY2_BUTTON_GPIO_RCC              RCC_AHBPeriph_GPIOA
#define KEY2_Status_Read()								GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)

#define KEY2_BUTTON_EXTI_PORT_SOURCE      EXTI_PortSourceGPIOA
#define KEY2_BUTTON_EXTI_PIN_SOURCE       EXTI_PinSource11
#define KEY2_BUTTON_EXTI_LINE             EXTI_Line11
#define KEY2_BUTTON_EXTI_IRQn             EXTI4_15_IRQn

void Exti_Config(void);
void KEY_EXTI_Config(void);

#endif
