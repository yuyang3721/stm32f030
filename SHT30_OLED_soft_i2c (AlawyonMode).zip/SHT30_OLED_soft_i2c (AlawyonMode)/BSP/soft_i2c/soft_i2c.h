#ifndef __SOFT_I2C_H
#define __SOFT_I2C_H

#include "stm32f0xx.h"

#define THS_I2C_SCL_PORT 			GPIOB
#define THS_I2C_SCL_PIN 			GPIO_Pin_6
#define THS_I2C_SDA_PORT 			GPIOB
#define THS_I2C_SDA_PIN 			GPIO_Pin_7
 
#define SCL_H         GPIOB->BSRR = GPIO_Pin_6	 /* GPIO_SetBits(GPIOB , GPIO_Pin_6)   */
#define SCL_L         GPIOB->BRR  = GPIO_Pin_6   /* GPIO_ResetBits(GPIOB , GPIO_Pin_6) */
   
#define SDA_H         GPIOB->BSRR = GPIO_Pin_7	 /* GPIO_SetBits(GPIOB , GPIO_Pin_7)   */
#define SDA_L         GPIOB->BRR  = GPIO_Pin_7	 /* GPIO_ResetBits(GPIOB , GPIO_Pin_7) */

#define SCL_read      GPIOB->IDR  & GPIO_Pin_6   /* GPIO_ReadInputDataBit(GPIOB , GPIO_Pin_6) */
#define SDA_read      GPIOB->IDR  & GPIO_Pin_7	 /* GPIO_ReadInputDataBit(GPIOB , GPIO_Pin_7) */
 
void SHT30_Init(void);						//SHT30 GPIO ��ʼ������
void SHT30_MeasureMode_Set(void);
void SHT30_read_result(uint8_t *pTempAndHumi);
void SHT30_read_status(uint8_t *pStadata);
void SHT30_SoftReset(void);
uint8_t Calc_CRC8(uint8_t *dat, uint8_t Num);
 
#endif

