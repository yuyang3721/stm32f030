#ifndef __Timer_H
#define	__Timer_H

#include "stm32f0xx.h"

void GENERAL_TIM_Init(void);

#endif
