#ifndef __PM25_H
#define __PM25_H
#include "stm32f0xx.h"

typedef struct
{
	uint16_t Buffer_Len;
	uint16_t PM1_0_CF;
	uint16_t PM2_5_CF;
	uint16_t PM10_CF;
	uint16_t PM1_0;
	uint16_t PM2_5;
	uint16_t PM10;
	uint16_t Count0_3nm;
	uint16_t Count0_5nm;
	uint16_t Count1_0nm;
	uint16_t Count2_5nm;
	uint16_t Count5_0nm;
	uint16_t Count10nm;
}PM_Sensor_DataStruct;

ErrorStatus	Check_PMSensor_DataValid(void);
void PMSensor_DataReflash(void);
#endif


