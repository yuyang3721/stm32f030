#include "./pm2.5/pm25.h"
#include "string.h"

extern 	PM_Sensor_DataStruct	PM_Sensor_Data;
extern  uint8_t 	PM_Sensor_RxBuffer[32];
extern  uint8_t    PM_Sensor_RxCount;

//Check_PMSensor_DataValid    //
//=============================================================================
ErrorStatus	Check_PMSensor_DataValid(void)
{
	uint16_t 	Cal_CheckSum;
	uint16_t 	Buffer_CheckSum;
	uint16_t 	Buffer_Len;
	uint8_t 	i;
	ErrorStatus Result = ERROR;

	if((PM_Sensor_RxBuffer[0] == 0x42)&&(PM_Sensor_RxBuffer[1] == 0x4d))
	{
		Buffer_Len = (uint16_t)((PM_Sensor_RxBuffer[2] << 8) | PM_Sensor_RxBuffer[3]);

		Buffer_CheckSum = (uint16_t)((PM_Sensor_RxBuffer[Buffer_Len + 2] << 8) | PM_Sensor_RxBuffer[Buffer_Len + 3]);

		Cal_CheckSum = 0;
		for(i=0;i<(Buffer_Len + 2);i++)
		{
			Cal_CheckSum += PM_Sensor_RxBuffer[i];
		}
		if(Cal_CheckSum == Buffer_CheckSum)
			Result = SUCCESS;
	}
	return Result;
}
//=============================================================================
//PMSensor_DataReflash    //
//=============================================================================
void PMSensor_DataReflash(void)
{
	memset(&PM_Sensor_Data,0,(sizeof(PM_Sensor_Data) - 2)); //PM_Sensor_Data set to zero

		PM_Sensor_Data.Buffer_Len = 28;
		PM_Sensor_Data.PM1_0_CF = (uint16_t)((PM_Sensor_RxBuffer[4]<<8) | PM_Sensor_RxBuffer[5]);
		PM_Sensor_Data.PM2_5_CF = (uint16_t)((PM_Sensor_RxBuffer[6]<<8) | PM_Sensor_RxBuffer[7]);
		PM_Sensor_Data.PM10_CF 	= (uint16_t)((PM_Sensor_RxBuffer[8]<<8) | PM_Sensor_RxBuffer[9]);
		PM_Sensor_Data.PM1_0 	= (uint16_t)((PM_Sensor_RxBuffer[10]<<8) | PM_Sensor_RxBuffer[11]);
		PM_Sensor_Data.PM2_5 	= (uint16_t)((PM_Sensor_RxBuffer[12]<<8) | PM_Sensor_RxBuffer[13]);
		PM_Sensor_Data.PM10 	= (uint16_t)((PM_Sensor_RxBuffer[14]<<8) | PM_Sensor_RxBuffer[15]);
		PM_Sensor_Data.Count0_3nm = (uint16_t)((PM_Sensor_RxBuffer[16]<<8) | PM_Sensor_RxBuffer[17]);
		PM_Sensor_Data.Count0_5nm = (uint16_t)((PM_Sensor_RxBuffer[18]<<8) | PM_Sensor_RxBuffer[19]);
		PM_Sensor_Data.Count1_0nm = (uint16_t)((PM_Sensor_RxBuffer[20]<<8) | PM_Sensor_RxBuffer[21]);
		PM_Sensor_Data.Count2_5nm = (uint16_t)((PM_Sensor_RxBuffer[22]<<8) | PM_Sensor_RxBuffer[23]);
		PM_Sensor_Data.Count5_0nm = (uint16_t)((PM_Sensor_RxBuffer[24]<<8) | PM_Sensor_RxBuffer[25]);
		PM_Sensor_Data.Count10nm = (uint16_t)((PM_Sensor_RxBuffer[26]<<8) | PM_Sensor_RxBuffer[27]); 
}




