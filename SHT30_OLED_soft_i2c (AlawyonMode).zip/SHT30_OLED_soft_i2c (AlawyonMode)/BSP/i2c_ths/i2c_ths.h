#ifndef __I2C_THS_
#define __I2C_THS_

#define THS_I2C 							I2C1
#define THS_I2C_SCL_PORT 			GPIOB
#define THS_I2C_SCL_PIN 			GPIO_Pin_6
#define THS_I2C_SDA_PORT 			GPIOB
#define THS_I2C_SDA_PIN 			GPIO_Pin_7

#define THS_I2C_TIMING1        0x0000020B				//400K	 	0   	0 		0 E
#define THS_I2C_TIMING2        0x2000090E				//100K 		0 		0 		0 E

#define THS_I2C_TIMING3        0x00101D7C				//50K 	 	0 		0 		0 E
#define THS_I2C_TIMING4        0x00201E7A				//50K  		100 	100 	0 E
#define THS_I2C_TIMING5        0x00108EFB				//20K  		0 		0 		0 E
#define THS_I2C_TIMING6        0x200009FE				//10K 		0 		0 		0 E



#define THS_I2C_ADDR       		0x88


#include "stm32f0xx.h"

void I2C_THS_Init(void);
void SHT30_GetStatus(uint8_t* pStatusBuffer);
//uint8_t SHT30_ReadTempAndHumi(uint8_t* pTemHmiBuffer);
uint8_t SHT30_ReadTempAndHumi(uint8_t* pTemHmiBuffer,uint8_t ReadNum);
void SHT30_MeasureMode(void);
uint8_t Calc_CRC8(uint8_t *dat, uint8_t Num);
#endif

