#include "./i2c_ths/i2c_ths.h"
#include "./usart/usart.h"

void I2C_THS_Init(void)
{ 
  I2C_InitTypeDef  I2C_InitStructure;
	GPIO_InitTypeDef  GPIO_InitStructure;
 /* ʹ��GPIOB������ʱ��*/
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
  /* ʹ��I2C1������ʱ��*/
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
  /* ����PB6Ϊ�ڶ���������I2C_SCL*/
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_1);
  /* ����PB6Ϊ�ڶ���������I2C_SDA*/
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_1);
  
  /* ����I2C����: SCL */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  /* ����I2C����:  SDA */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  /* ����I2C1�Ĵ�������*/
  I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
  I2C_InitStructure.I2C_AnalogFilter = I2C_AnalogFilter_Enable;
  I2C_InitStructure.I2C_DigitalFilter = 0x00;
  I2C_InitStructure.I2C_OwnAddress1 = 0x00;
  I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
  I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
  I2C_InitStructure.I2C_Timing = THS_I2C_TIMING1;                                                                                       
  /* ʹ��I2C����*/
  I2C_Cmd(I2C1, ENABLE);
 /* ��ʼ��I2C����Ĵ���*/
  I2C_Init(I2C1, &I2C_InitStructure);

}

void SHT30_MeasureMode(void)
{
	I2C_TransferHandling(I2C1,THS_I2C_ADDR,2, I2C_SoftEnd_Mode, I2C_Generate_Start_Write);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TXIS) == RESET);

	I2C_SendData(I2C1,0x21);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TXIS) == RESET);
	
	I2C_SendData(I2C1,0x30);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TC) == RESET);		
}

void SHT30_GetStatus(uint8_t* pStatusBuffer)
{
	I2C_TransferHandling(I2C1,THS_I2C_ADDR,2, I2C_SoftEnd_Mode, I2C_Generate_Start_Write);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TXIS) == RESET);

	I2C_SendData(I2C1,0xF3);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TXIS) == RESET);
	
	I2C_SendData(I2C1,0x2D);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TC) == RESET);	
	
	I2C_TransferHandling(I2C1, THS_I2C_ADDR, 3,  I2C_AutoEnd_Mode, I2C_Generate_Start_Read);
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);
	
	pStatusBuffer[0] = I2C_ReceiveData(I2C1);
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);	
	
	pStatusBuffer[1] = I2C_ReceiveData(I2C1);
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);	

	pStatusBuffer[2] = I2C_ReceiveData(I2C1);
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_STOPF) == RESET);		
	
}

uint8_t SHT30_ReadTempAndHumi(uint8_t* pTemHmiBuffer,uint8_t ReadNum)
////uint8_t SHT30_ReadTempAndHumi(uint8_t* pTemHmiBuffer)
{
	uint8_t i ;
//	uint16_t k = 1000;
	I2C_TransferHandling(I2C1,THS_I2C_ADDR,2, I2C_SoftEnd_Mode, I2C_Generate_Start_Write);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TXIS) == RESET);

	I2C_SendData(I2C1,0xE0);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TXIS) == RESET);
	
	I2C_SendData(I2C1,0x00);
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_TC) == RESET);	
	
	I2C_TransferHandling(I2C1, THS_I2C_ADDR, ReadNum, I2C_AutoEnd_Mode, I2C_Generate_Start_Read);
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);
	
	for(i = 0;i < ReadNum-1 ;i++)
	{
		pTemHmiBuffer[i] = I2C_ReceiveData(I2C1);
		while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);
//		{
//			k--;
//			if(k == 0)
//			{
//			printf("\n������λ \n");			
//			//NVI C_SystemReset();
//			}
//		}
	}
	pTemHmiBuffer[ReadNum-1] = I2C_ReceiveData(I2C1);
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_STOPF) == RESET);

////	I2C_TransferHandling(I2C1, THS_I2C_ADDR, 6, I2C_AutoEnd_Mode, I2C_Generate_Start_Read);
////	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);
////	
////	pTemHmiBuffer[0] = I2C_ReceiveData(I2C1);
////	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);	
////	
////	pTemHmiBuffer[1] = I2C_ReceiveData(I2C1);
////	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);	

////	pTemHmiBuffer[2] = I2C_ReceiveData(I2C1);
////	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);

////	pTemHmiBuffer[3] = I2C_ReceiveData(I2C1);
////	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);	
////	
////	pTemHmiBuffer[4] = I2C_ReceiveData(I2C1);
////	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET);	

////	pTemHmiBuffer[5] = I2C_ReceiveData(I2C1);
////	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_STOPF) == RESET);
	
	return 1;	
}

uint8_t Calc_CRC8(uint8_t *dat, uint8_t Num)
{
	int i,byte,crc=0xFF;
		for(byte=0; byte<Num; byte++)
		{
			crc^=(dat[byte]);
			for(i=0;i<8;i++)
			{
				if(crc & 0x80) crc=(crc<<1)^0x31;
				else crc=(crc<<1);
			}
		}
	return crc;
}



