#ifndef __USART_H
#define __USART_H

#include "stm32f0xx.h"
#include <stdio.h>


void USART1_Config(void);
void USART2_Config(void);

#endif
